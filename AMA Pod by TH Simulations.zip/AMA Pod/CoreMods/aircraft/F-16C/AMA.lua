--AMA Pod model by Hoon, coding by Tango-17, Textures by Roughmaster.

--T/H Simulations AMA mod --Blue
declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{AMA_BLUE}",
		attribute		=  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},
		Picture			= "Blue_AMA_icon.png",
		Weight_Empty	= 85.5,
		Weight			= 85.5,
		Cx_pil			= 0.0,
		displayName		= _("Acceleration Monitor Assembly - blue"),
		
		shape_table_data = 
		{
			{
				name 	= "AMA_blue",
				file	= "AMA_blue";
				life	= 1;
				fire	= { 0, 1};
				username	= "AMA_blue";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Elements	= 
		{
			{
				ShapeName	= "AMA_blue",
			}, 
		}, 
	}
)

--T/H Simulations AMA mod --Grey
declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{AMA_GREY}",
		attribute		=  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},
		Picture			= "Grey_AMA_icon.png",
		Weight_Empty	= 85.5,
		Weight			= 85.5,
		Cx_pil			= 0.0,
		displayName		= _("Acceleration Monitor Assembly - grey"),
		
		shape_table_data = 
		{
			{
				name 	= "AMA_grey",
				file	= "AMA_grey";
				life	= 1;
				fire	= { 0, 1};
				username	= "AMA_grey";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Elements	= 
		{
			{
				ShapeName	= "AMA_grey",
			}, 
		}, 
	}
)

--T/H Simulations AMA mod --Orange
declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{AMA_ORANGE}",
		attribute		=  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},
		Picture			= "Orange_AMA_icon.png",
		Weight_Empty	= 85.5,
		Weight			= 85.5,
		Cx_pil			= 0.0,
		displayName		= _("Acceleration Monitor Assembly - orange"),
		
		shape_table_data = 
		{
			{
				name 	= "AMA_orange",
				file	= "AMA_orange";
				life	= 1;
				fire	= { 0, 1};
				username	= "AMA_orange";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Elements	= 
		{
			{
				ShapeName	= "AMA_orange",
			}, 
		}, 
	}
)

--T/H Simulations AMA mod --No Fins, used by RNLAF
declare_loadout(
	{
		category		= CAT_PODS,
		CLSID			= "{AMA_NOFIN}",
		attribute		=  {wsType_Air,wsType_Free_Fall,wsType_FuelTank,WSTYPE_PLACEHOLDER},
		Picture			= "NoFin_AMA_icon.png",
		Weight_Empty	= 85.5,
		Weight			= 85.5,
		Cx_pil			= 0.0,
		displayName		= _("Acceleration Monitor Assembly - no fins"),
		
		shape_table_data = 
		{
			{
				name 	= "AMA_nofin",
				file	= "AMA_nofin";
				life	= 1;
				fire	= { 0, 1};
				username	= "AMA_nofin";
				index	= WSTYPE_PLACEHOLDER;
			},
		},
		Elements	= 
		{
			{
				ShapeName	= "AMA_nofin",
			}, 
		}, 
	}
)