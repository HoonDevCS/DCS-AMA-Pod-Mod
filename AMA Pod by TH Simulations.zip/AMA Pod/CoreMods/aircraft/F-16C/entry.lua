declare_plugin("F-16C bl.50 AI",{
version		 	  = __DCS_VERSION__,		 
state		 	  = "installed",
})

mount_vfs_model_path	(current_mod_path.."/Shapes")
mount_vfs_liveries_path (current_mod_path.."/Liveries")
mount_vfs_texture_path  (current_mod_path.."/Textures/F16C_bl50")
mount_vfs_texture_path  (current_mod_path.."/Textures/F16C_bl50_HAF")
mount_vfs_texture_path  (current_mod_path.."/Textures/F16C_bl50_IAF")
mount_vfs_texture_path  (current_mod_path.."/Textures/AMA_Blue") --T/H Simulations AMA mod
mount_vfs_texture_path  (current_mod_path.."/Textures/AMA_Grey") --T/H Simulations AMA mod
mount_vfs_texture_path  (current_mod_path.."/Textures/AMA_Orange") --T/H Simulations AMA mod
---------------------------------------------------------
dofile(current_mod_path..'/F-16C.lua')
dofile(current_mod_path..'/AMA.lua') --T/H Simulations AMA mod
---------------------------------------------------------
plugin_done()	